<?php
// index.php - public home page
require 'db.php';
require_once 'includes/functions.php';
$stats = $conn->query("SELECT (SELECT COUNT(*) FROM books) AS titles,
                              (SELECT COALESCE(SUM(available_copies),0) FROM books) AS avail,
                              (SELECT COUNT(*) FROM members) AS members")->fetch_assoc();
$recent = $conn->query("SELECT b.title, b.author, b.available_copies, c.category_name
                        FROM books b JOIN categories c ON c.category_id = b.category_id
                        ORDER BY b.added_on DESC, b.book_id DESC LIMIT 6");
$page_title = 'Home';
include 'includes/header.php';
?>
<section class="hero">
<h1>Welcome to City Library</h1>
<p>Search the catalogue, check availability, and track your borrowed books and fines online.</p>
<form class="search" action="search.php" method="get">
<input name="q" placeholder="Search by title, author or ISBN..."><button>Search</button></form>
<div class="actions" style="margin-top:14px">
<a class="btn light" href="member_register.php">Become a Member</a>
<a class="btn light" href="member_login.php">Member Login</a></div>
</section>
<div class="grid">
<div class="stat">Book Titles<strong><?= (int)$stats['titles'] ?></strong></div>
<div class="stat">Copies on Shelf<strong><?= (int)$stats['avail'] ?></strong></div>
<div class="stat">Members<strong><?= (int)$stats['members'] ?></strong></div>
</div>
<div class="card"><h2>Recently Added</h2>
<div class="table-wrap"><table><tr><th>Title</th><th>Author</th><th>Category</th><th>Status</th></tr>
<?php if ($recent->num_rows): while ($b = $recent->fetch_assoc()): ?>
<tr><td><?= h($b['title']) ?></td><td><?= h($b['author']) ?></td><td><?= h($b['category_name']) ?></td>
<td><?= $b['available_copies'] > 0 ? '<span class="pill ok">Available</span>' : '<span class="pill no">Not available</span>' ?></td></tr>
<?php endwhile; else: ?><tr><td colspan="4">No books yet.</td></tr><?php endif; ?>
</table></div>
<p><a href="search.php">Browse the full catalogue &rarr;</a></p></div>
<?php include 'includes/footer.php'; ?>
