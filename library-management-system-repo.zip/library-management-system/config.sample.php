<?php
// config.sample.php - copy to config.php and edit (install_ubuntu.sh does this for you)
return [
    'db_host' => 'localhost',
    'db_user' => 'library_user',
    'db_pass' => 'change_me',
    'db_name' => 'library',
];
