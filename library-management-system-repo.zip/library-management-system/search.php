<?php
// search.php - search catalogue by title, author or ISBN
require 'db.php';
require_once 'includes/functions.php';
$raw = trim($_GET['q'] ?? '');
$q = '%' . $raw . '%';
$stmt = $conn->prepare(
    "SELECT b.title, b.author, b.isbn, b.available_copies, b.total_copies, b.shelf_location, c.category_name
     FROM books b JOIN categories c ON c.category_id = b.category_id
     WHERE b.title LIKE ? OR b.author LIKE ? OR b.isbn LIKE ?
     ORDER BY b.title");
$stmt->bind_param("sss", $q, $q, $q);
$stmt->execute();
$result = $stmt->get_result();
$page_title = 'Catalogue';
include 'includes/header.php';
?>
<div class="card"><h2>Book Catalogue</h2>
<form class="search" method="get"><input name="q" value="<?= h($raw) ?>" placeholder="Title, author or ISBN..."><button>Search</button></form>
<p class="muted"><?= $result->num_rows ?> book(s) found<?= $raw !== '' ? ' for "' . h($raw) . '"' : '' ?>.</p>
<div class="table-wrap"><table>
<tr><th>Title</th><th>Author</th><th>ISBN</th><th>Category</th><th>Shelf</th><th>Availability</th></tr>
<?php if ($result->num_rows): while ($b = $result->fetch_assoc()): ?>
<tr><td><?= h($b['title']) ?></td><td><?= h($b['author']) ?></td><td><?= h($b['isbn']) ?></td>
<td><?= h($b['category_name']) ?></td><td><?= h($b['shelf_location']) ?></td>
<td><?= $b['available_copies'] > 0
    ? '<span class="pill ok">Available</span> ' . (int)$b['available_copies'] . '/' . (int)$b['total_copies']
    : '<span class="pill no">Not available</span>' ?></td></tr>
<?php endwhile; else: ?><tr><td colspan="6">No books found.</td></tr><?php endif; ?>
</table></div></div>
<?php include 'includes/footer.php'; ?>
