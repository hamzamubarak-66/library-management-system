# Narration script: Library Management System code walkthrough

(Use this if you want to record your own voice in Loom.)

## 1. Library Management System  (`Project overview`)

Hello! In this video I will explain the code of the Library Management System in simple words. It is a website built with PHP, MySQL, CSS and the Apache server, running on Ubuntu. The librarian can manage books, members, issues, returns and fines. Members can search books and see what they borrowed. The rules are simple: a book is lent for fourteen days, each member can hold three books, and a late book costs ten rupees per day.

## 2. Folder map  (`library/`)

First, the folder map. Files in the main folder are for visitors and members, like the home page, search, and login. The admin folder holds every librarian page. The includes folder has pieces that every page shares, such as the header and footer. The database folder creates the tables, and the deploy folder installs everything on Ubuntu.

## 3. Connecting to the database  (`db.php`)

Next, db dot php. This file opens the connection to MySQL. The username and password are kept in a separate file called config dot php, so secrets are not mixed into the code. Any page that needs data simply requires db dot php, and gets a variable called conn. The installer also creates a limited database user, so the website never runs as the powerful root user.

## 4. The database: 6 tables  (`database/schema.sql`)

The database has six tables. Admins, members, categories, books, issues and fines. Each piece of information is stored only once, and tables are linked with foreign keys. For example, every issue points to a book and a member. Because of this, you cannot delete a book that has borrow history. The books table keeps two numbers: total copies, and available copies on the shelf.

## 5. Shared helpers  (`includes/functions.php`)

The file functions dot php holds tools used everywhere. At the top are the three library rules: loan days, maximum books, and fine per day. Change a number here and the whole site follows. The function h makes text safe before showing it, which stops attackers from injecting scripts. csrf check makes sure a form really came from our own page. And sessions are started here, so logins work on every page.

## 6. Same look on every page  (`includes/header.php + footer.php`)

Header dot php and footer dot php give every page the same look. Each page includes the header at the top and the footer at the bottom. The menu changes depending on who is logged in: guest, member, or admin. Admin pages also get a sidebar. The base variable fixes file paths, so the style sheet loads correctly even from inside the admin folder.

## 7. Admin login  (`admin_login.php`)

Now the admin login. The username goes into the query through a question mark placeholder. This is called a prepared statement, and it blocks SQL injection. Passwords are never stored as plain text. They are stored as a hash, and password verify checks what the user typed. If it matches, we save the admin id in the session, and send them to the dashboard.

## 8. Guarding the admin pages  (`admin/auth.php`)

This tiny file protects the whole admin area. Every admin page starts by requiring auth dot php. If there is no admin in the session, the visitor is sent straight back to the login page. Dangerous actions like delete, return, and pay are also POST only and carry a security token.

## 9. Members: register, login, my books  (`member_register.php / my_books.php`)

Members can register themselves. Their password is hashed before saving. A blocked member cannot log in. After login, the My Books page shows current loans, past returns, and any fines. The number of overdue days is calculated by the database itself, using date diff.

## 10. Searching the catalogue  (`search.php`)

Search dot php lets anyone find a book by title, author, or ISBN. The percent signs mean partial match, so typing clean finds Clean Code. The page then shows whether each book is available, and where it sits on the shelf.

## 11. Managing books  (`admin/add_book.php + edit_book.php`)

The admin adds books with a prepared insert. A new book starts with all copies available. When editing the total copies, the code first works out how many copies are currently out on loan, and adjusts the shelf count by the same amount. So the stock number can never become wrong, and you cannot set the total lower than the copies on loan.

## 12. Issuing a book  (`admin/issue_book.php`)

This is the heart of the system. Issuing a book runs inside a database transaction. A transaction means all steps succeed together, or none of them do. First it checks the member is active, has fewer than three books, and that a copy is available. Then it creates the issue record with the due date set automatically to today plus fourteen days, and reduces the available copies by one. If anything fails, rollback undoes everything, so the data never gets mixed up.

## 13. Returning a book and the fine  (`admin/return_book.php`)

Returning works the same way. The code counts how many days late the book is, never going below zero. The fine is late days times ten rupees. It marks the issue as returned, puts the copy back on the shelf, and creates a fine record only if the book was late. For example, five days late means a fifty rupee fine.

## 14. Overdue list and fines  (`admin/overdue.php + fines.php`)

The overdue page lists every book that is past its due date, with the longest delay first, and the fine so far. The fines page shows what is unpaid and what has been collected. With one click, Mark Paid saves the payment date. The dashboard shows all these totals at a glance.

## 15. Security summary  (`whole project`)

Let's recap the security. Passwords are hashed. Prepared statements stop SQL injection. Output is escaped to stop script injection. Every form has a security token, and risky actions are POST only. Transactions keep the stock correct. And Apache blocks direct access to the config and include files.

## 16. Run it on Ubuntu  (`deploy/install_ubuntu.sh`)

Finally, to run it on Ubuntu, unzip the project and run the install script with sudo. It installs Apache, PHP and MariaDB, creates the database, the admin account and sample books, and prints your admin password at the end. Then open localhost slash library in your browser. Thank you for watching!

