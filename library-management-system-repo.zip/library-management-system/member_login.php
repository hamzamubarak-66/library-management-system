<?php
// member_login.php
require 'db.php';
require_once 'includes/functions.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $email = trim($_POST['email'] ?? '');
    $stmt = $conn->prepare("SELECT member_id, name, password, status FROM members WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $m = $stmt->get_result()->fetch_assoc();
    if ($m && password_verify($_POST['password'] ?? '', $m['password'])) {
        if ($m['status'] !== 'Active') {
            $error = 'Your account is blocked. Please contact the librarian.';
        } else {
            session_regenerate_id(true);
            unset($_SESSION['admin_id'], $_SESSION['admin_name']);
            $_SESSION['member_id'] = $m['member_id'];
            $_SESSION['member_name'] = $m['name'];
            redirect('my_books.php');
        }
    } else {
        $error = 'Invalid email or password.';
    }
}
$page_title = 'Member Login';
include 'includes/header.php';
?>
<div class="card narrow"><h2>Member Login</h2>
<?php if ($error): ?><div class="error"><?= h($error) ?></div><?php endif; ?>
<form method="post"><?= csrf_field() ?>
<label>Email</label><input type="email" name="email" required autofocus>
<label>Password</label><input type="password" name="password" required>
<button>Login</button></form>
<p class="muted">New here? <a href="member_register.php">Create an account</a>.</p></div>
<?php include 'includes/footer.php'; ?>
