#!/usr/bin/env bash
# install_ubuntu.sh - one-command LAMP setup for the Library Management System
# Tested target: Ubuntu 22.04 / 24.04.   Run from the project folder:  sudo bash deploy/install_ubuntu.sh
set -euo pipefail

if [[ $EUID -ne 0 ]]; then echo "Please run with sudo:  sudo bash $0"; exit 1; fi

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WEBROOT="/var/www/html/library"
DB_NAME="library"
DB_USER="library_user"
DB_PASS="$(openssl rand -hex 12)"
ADMIN_USER="admin"
ADMIN_PASS="${ADMIN_PASS:-$(openssl rand -base64 9 | tr -d '/+=' | head -c 12)}"
export DEBIAN_FRONTEND=noninteractive

echo "==> [1/6] Installing Apache, PHP and MariaDB"
apt-get update -y
apt-get install -y apache2 php libapache2-mod-php php-mysql php-cli mariadb-server openssl

echo "==> [2/6] Starting services"
systemctl enable --now mariadb
systemctl enable --now apache2

echo "==> [3/6] Creating database, tables and DB user"
mysql < "$SRC/database/schema.sql"
mysql -e "CREATE USER IF NOT EXISTS '$DB_USER'@'localhost' IDENTIFIED BY '$DB_PASS';
          ALTER USER '$DB_USER'@'localhost' IDENTIFIED BY '$DB_PASS';
          GRANT SELECT,INSERT,UPDATE,DELETE ON $DB_NAME.* TO '$DB_USER'@'localhost';
          FLUSH PRIVILEGES;"

echo "==> [4/6] Copying project to $WEBROOT"
mkdir -p "$WEBROOT"
rsync -a --delete --exclude 'config.php' --exclude '.git' "$SRC/" "$WEBROOT/" 2>/dev/null \
  || { cp -a "$SRC/." "$WEBROOT/"; }
cat > "$WEBROOT/config.php" <<PHP
<?php
return [
    'db_host' => 'localhost',
    'db_user' => '$DB_USER',
    'db_pass' => '$DB_PASS',
    'db_name' => '$DB_NAME',
];
PHP
chown -R www-data:www-data "$WEBROOT"
find "$WEBROOT" -type d -exec chmod 755 {} \;
find "$WEBROOT" -type f -exec chmod 644 {} \;
chmod 640 "$WEBROOT/config.php"

echo "==> [5/6] Creating the admin account"
php "$WEBROOT/deploy/create_admin.php" "$ADMIN_USER" "$ADMIN_PASS" "Library Administrator"

if [[ "${LOAD_SAMPLE_DATA:-yes}" == "yes" ]]; then
  echo "==> Loading sample categories and books"
  mysql < "$SRC/database/sample_data.sql"
fi

echo "==> [6/6] Hardening Apache (block config and SQL files) and reloading"
cat > /etc/apache2/conf-available/library-protect.conf <<'CONF'
<Directory /var/www/html/library>
    Options -Indexes
    <FilesMatch "^(config(\.sample)?\.php|.*\.sql|.*\.sh)$">
        Require all denied
    </FilesMatch>
</Directory>
<Directory /var/www/html/library/includes>
    Require all denied
</Directory>
<Directory /var/www/html/library/deploy>
    Require all denied
</Directory>
<Directory /var/www/html/library/database>
    Require all denied
</Directory>
CONF
a2enconf library-protect >/dev/null
systemctl reload apache2

IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
echo
echo "=============================================================="
echo " Library Management System installed."
echo "  Website : http://localhost/library/   (or http://${IP:-your-ip}/library/)"
echo "  Admin   : http://localhost/library/admin_login.php"
echo "  Login   : $ADMIN_USER / $ADMIN_PASS   <-- save this password"
echo "=============================================================="
