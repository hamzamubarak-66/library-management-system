<?php
// deploy/create_admin.php - CLI helper: php create_admin.php <username> <password> "<Full Name>"
// Creates or updates an admin using password_hash().
if (PHP_SAPI !== 'cli') exit('CLI only.');
if ($argc < 4) exit("Usage: php create_admin.php <username> <password> \"<Full Name>\"\n");
require __DIR__ . '/../db.php';
[, $u, $p, $n] = $argv;
$hash = password_hash($p, PASSWORD_DEFAULT);
$st = $conn->prepare("INSERT INTO admins (username,password,full_name) VALUES (?,?,?)
                      ON DUPLICATE KEY UPDATE password=VALUES(password), full_name=VALUES(full_name)");
$st->bind_param("sss", $u, $hash, $n);
$st->execute();
echo "Admin '$u' saved.\n";
