# Library Management System (PHP + MariaDB/MySQL + Apache) — Ubuntu Edition

![PHP](https://img.shields.io/badge/PHP-8.x-777bb4) ![MariaDB](https://img.shields.io/badge/MariaDB-10.x-003545) ![Ubuntu](https://img.shields.io/badge/Ubuntu-22.04%20%7C%2024.04-e95420) ![License](https://img.shields.io/badge/license-MIT-green)

Web Technologies project · Hamza Mubarak · BCSF24A044

Features: admin login, books / categories / members CRUD, issue & return with transactions,
14-day due dates, limit of 3 books per member, Rs. 10/day fines, overdue report, fine collection,
public catalogue search, member registration/login, "My Books" page with fines.

## 1. Quick install on Ubuntu (22.04 / 24.04)

```bash
git clone https://github.com/<your-username>/library-management-system.git
cd library-management-system
sudo bash deploy/install_ubuntu.sh
```

The script installs Apache, PHP, MariaDB; creates the `library` database and a limited DB user;
copies the site to `/var/www/html/library`; creates the admin account with a random password;
loads sample books; and blocks web access to `config.php`, `includes/`, `database/`, `deploy/`.

At the end it prints the URLs and the admin password. Then open:

* Website: http://localhost/library/
* Admin:   http://localhost/library/admin_login.php

Options (environment variables):

```bash
sudo ADMIN_PASS='MyStrongPass1' LOAD_SAMPLE_DATA=no bash deploy/install_ubuntu.sh
```

## 2. Manual install (what the script does)

```bash
sudo apt update
sudo apt install -y apache2 php libapache2-mod-php php-mysql mariadb-server
sudo systemctl enable --now apache2 mariadb

# database
sudo mysql < database/schema.sql
sudo mysql < database/sample_data.sql          # optional demo data
sudo mysql -e "CREATE USER 'library_user'@'localhost' IDENTIFIED BY 'ChangeMe123';
               GRANT SELECT,INSERT,UPDATE,DELETE ON library.* TO 'library_user'@'localhost';"

# site
sudo cp -r . /var/www/html/library
cd /var/www/html/library
sudo cp config.sample.php config.php && sudo nano config.php     # put the DB password in
sudo chown -R www-data:www-data .
sudo php deploy/create_admin.php admin 'MyStrongPass1' 'Library Administrator'
```

## 3. Quick test without Apache (development)

```bash
sudo apt install -y php-cli php-mysql mariadb-server
sudo mysql < database/schema.sql && sudo mysql < database/sample_data.sql
cp config.sample.php config.php     # edit credentials
php deploy/create_admin.php admin 'MyStrongPass1' 'Library Administrator'
php -S 0.0.0.0:8000
# open http://localhost:8000
```

## 4. Project structure (matches the report, section 5.4)

```
library-management-system/
├── docs/       code-walkthrough.mp4  video-script.md
├── index.php  search.php  member_login.php  member_register.php  my_books.php
├── logout.php  admin_login.php  db.php  config.sample.php
├── css/style.css
├── includes/   header.php  footer.php  functions.php  book_form.php
├── admin/      auth.php dashboard.php books.php add_book.php edit_book.php delete_book.php
│               categories.php members.php issue_book.php return_book.php
│               issues.php overdue.php fines.php
├── database/   schema.sql  sample_data.sql
└── deploy/     install_ubuntu.sh  create_admin.php
```

## 5. Library rules

Edit the three constants at the top of `includes/functions.php`:
`LOAN_DAYS = 14`, `MAX_BOOKS = 3`, `FINE_PER_DAY = 10`.

## 6. Security measures

* Passwords hashed with `password_hash()` / checked with `password_verify()`
* Prepared statements for every query that uses input; `htmlspecialchars()` on all output
* CSRF token on every form; delete/return/pay actions are POST-only
* `session_regenerate_id()` on login, session check on every admin page
* Issue/return run in DB transactions with row locks (stock never goes inconsistent)
* App uses a DB user without DROP/ALTER rights, not MySQL root
* Apache config blocks `config.php`, `includes/`, `database/`, `deploy/`

## 7. Troubleshooting

| Problem | Fix |
|---|---|
| "Database connection failed" | `sudo systemctl status mariadb`; check `config.php` credentials |
| Blank page / 500 error | `sudo tail -n 30 /var/log/apache2/error.log` |
| Forgot admin password | `php deploy/create_admin.php admin 'NewPass1' 'Library Administrator'` |
| 403 on `/library/` | `sudo chown -R www-data:www-data /var/www/html/library` |
| Port 80 busy | `sudo ss -ltnp \| grep :80`, stop the other service |

## 8. Notes vs. the original starter zip

The original zip was a flat XAMPP/Windows layout with a broken `setup.php` (JavaScript-style `conn.query`),
a header/footer that closed the HTML before page content, missing return/overdue/fines/edit pages,
and a CSS link that broke inside `admin/`. This version fixes those and follows the report's design.

## 9. Docs

* `docs/code-walkthrough.mp4` - narrated video explaining the code files in simple words
* `docs/video-script.md` - the narration script

## License

MIT - see `LICENSE`.
