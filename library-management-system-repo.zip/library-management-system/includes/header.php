<?php
// includes/header.php - $base ('' or '../') and $page_title are set by the page
require_once __DIR__ . '/functions.php';
$base = $base ?? '';
$is_admin_page = !empty($is_admin_page);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($page_title ?? 'Library Management System') ?> | City Library</title>
<link rel="stylesheet" href="<?= $base ?>css/style.css">
</head>
<body>
<header class="topbar">
  <a class="brand" href="<?= $base ?>index.php">City Library</a>
  <nav>
    <a href="<?= $base ?>index.php">Home</a>
    <a href="<?= $base ?>search.php">Catalogue</a>
    <?php if (!empty($_SESSION['member_id'])): ?>
      <a href="<?= $base ?>my_books.php">My Books</a><a href="<?= $base ?>logout.php">Logout</a>
    <?php elseif (!empty($_SESSION['admin_id'])): ?>
      <a href="<?= $base ?>admin/dashboard.php">Admin Panel</a><a href="<?= $base ?>logout.php">Logout</a>
    <?php else: ?>
      <a href="<?= $base ?>member_login.php">Member Login</a>
      <a href="<?= $base ?>member_register.php">Register</a>
      <a href="<?= $base ?>admin_login.php">Admin</a>
    <?php endif; ?>
  </nav>
</header>
<?php if ($is_admin_page): $cur = basename($_SERVER['SCRIPT_NAME']); ?>
<div class="layout">
<aside class="sidebar">
  <h3>Librarian</h3>
  <?php
  $links = ['dashboard.php'=>'Dashboard','books.php'=>'Books','categories.php'=>'Categories','members.php'=>'Members',
            'issue_book.php'=>'Issue Book','issues.php'=>'Issues / Returns','overdue.php'=>'Overdue','fines.php'=>'Fines'];
  foreach ($links as $f => $label)
      echo '<a class="' . ($cur === $f ? 'active' : '') . '" href="' . $f . '">' . $label . '</a>';
  ?>
</aside>
<main class="content">
<?php else: ?>
<main class="container">
<?php endif; show_flash(); ?>
