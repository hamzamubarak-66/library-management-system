</main>
<?php if (!empty($is_admin_page)) echo '</div>'; ?>
<footer>Library Management System &middot; Web Technologies Project</footer>
</body>
</html>
