<?php
// includes/functions.php - sessions, helpers, CSRF, access control
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
    session_start();
}

// Library rules (change here)
const LOAN_DAYS    = 14;  // loan period in days
const MAX_BOOKS    = 3;   // max active books per member
const FINE_PER_DAY = 10;  // Rs. per late day

function h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function flash(string $msg, string $type = 'ok'): void { $_SESSION['flash'] = [$msg, $type]; }
function show_flash(): void {
    if (!empty($_SESSION['flash'])) {
        [$m, $t] = $_SESSION['flash'];
        echo '<div class="' . ($t === 'err' ? 'error' : 'notice') . '">' . h($m) . '</div>';
        unset($_SESSION['flash']);
    }
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrf_field(): string { return '<input type="hidden" name="csrf" value="' . h(csrf_token()) . '">'; }
function csrf_check(): void {
    $ok = isset($_POST['csrf']) && hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf']);
    if (!$ok) { http_response_code(400); exit('Invalid or missing security token. Go back and reload the page.'); }
}
function require_post(): void {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit('POST required.'); }
    csrf_check();
}

function redirect(string $url): never { header('Location: ' . $url); exit; }

function require_member(): void {
    if (empty($_SESSION['member_id'])) redirect('member_login.php');
}
