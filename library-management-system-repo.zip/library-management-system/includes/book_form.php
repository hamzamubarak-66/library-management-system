<?php
// includes/book_form.php - shared form for add_book.php and edit_book.php
// expects $book (array), $cats (mysqli_result), $submit_label
?>
<form method="post"><?= csrf_field() ?>
<label>ISBN</label><input name="isbn" required maxlength="20" value="<?= h($book['isbn']) ?>">
<label>Title</label><input name="title" required maxlength="200" value="<?= h($book['title']) ?>">
<label>Author</label><input name="author" required maxlength="120" value="<?= h($book['author']) ?>">
<label>Publisher</label><input name="publisher" maxlength="120" value="<?= h($book['publisher']) ?>">
<label>Category</label><select name="category_id" required>
<?php while ($c = $cats->fetch_assoc()): ?>
<option value="<?= (int)$c['category_id'] ?>" <?= (int)$book['category_id'] === (int)$c['category_id'] ? 'selected' : '' ?>><?= h($c['category_name']) ?></option>
<?php endwhile; ?></select>
<label>Total copies</label><input type="number" name="copies" min="1" required value="<?= (int)$book['total_copies'] ?>">
<label>Shelf location (e.g. A-12)</label><input name="shelf" maxlength="30" value="<?= h($book['shelf_location']) ?>">
<div class="actions"><button><?= h($submit_label) ?></button><a class="btn secondary" href="books.php">Cancel</a></div>
</form>
