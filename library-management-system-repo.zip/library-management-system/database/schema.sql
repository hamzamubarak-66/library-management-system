-- database/schema.sql - Library Management System (MariaDB / MySQL)
-- Usage:  sudo mysql < database/schema.sql
CREATE DATABASE IF NOT EXISTS library CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE library;

CREATE TABLE IF NOT EXISTS admins (
  admin_id  INT AUTO_INCREMENT PRIMARY KEY,
  username  VARCHAR(50)  NOT NULL UNIQUE,
  password  VARCHAR(255) NOT NULL,
  full_name VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS members (
  member_id INT AUTO_INCREMENT PRIMARY KEY,
  name      VARCHAR(100) NOT NULL,
  email     VARCHAR(120) NOT NULL UNIQUE,
  phone     VARCHAR(20),
  address   TEXT,
  password  VARCHAR(255) NOT NULL,
  join_date DATE DEFAULT (CURRENT_DATE),
  status    ENUM('Active','Blocked') DEFAULT 'Active'
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS categories (
  category_id   INT AUTO_INCREMENT PRIMARY KEY,
  category_name VARCHAR(80) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS books (
  book_id          INT AUTO_INCREMENT PRIMARY KEY,
  isbn             VARCHAR(20)  NOT NULL UNIQUE,
  title            VARCHAR(200) NOT NULL,
  author           VARCHAR(120) NOT NULL,
  publisher        VARCHAR(120),
  category_id      INT NOT NULL,
  total_copies     INT NOT NULL DEFAULT 1,
  available_copies INT NOT NULL DEFAULT 1,
  shelf_location   VARCHAR(30),
  added_on         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(category_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS issues (
  issue_id    INT AUTO_INCREMENT PRIMARY KEY,
  book_id     INT NOT NULL,
  member_id   INT NOT NULL,
  issued_by   INT NOT NULL,
  issue_date  DATE NOT NULL,
  due_date    DATE NOT NULL,
  return_date DATE NULL,
  status      ENUM('Issued','Returned') DEFAULT 'Issued',
  FOREIGN KEY (book_id)   REFERENCES books(book_id),
  FOREIGN KEY (member_id) REFERENCES members(member_id),
  FOREIGN KEY (issued_by) REFERENCES admins(admin_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS fines (
  fine_id   INT AUTO_INCREMENT PRIMARY KEY,
  issue_id  INT NOT NULL UNIQUE,
  amount    DECIMAL(8,2) NOT NULL,
  paid      TINYINT(1) DEFAULT 0,
  paid_date DATE NULL,
  FOREIGN KEY (issue_id) REFERENCES issues(issue_id)
) ENGINE=InnoDB;
