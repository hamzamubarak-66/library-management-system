-- database/sample_data.sql - optional demo categories and books
USE library;
INSERT IGNORE INTO categories (category_name) VALUES ('Fiction'),('Science'),('History'),('Computer Science'),('Islamic Studies');
INSERT IGNORE INTO books (isbn,title,author,publisher,category_id,total_copies,available_copies,shelf_location) VALUES
('9780132350884','Clean Code','Robert C. Martin','Prentice Hall',(SELECT category_id FROM categories WHERE category_name='Computer Science'),3,3,'CS-01'),
('9780262033848','Introduction to Algorithms','Cormen, Leiserson, Rivest, Stein','MIT Press',(SELECT category_id FROM categories WHERE category_name='Computer Science'),2,2,'CS-02'),
('9781491954249','Designing Data-Intensive Applications','Martin Kleppmann','O''Reilly',(SELECT category_id FROM categories WHERE category_name='Computer Science'),2,2,'CS-03'),
('9780553380163','A Brief History of Time','Stephen Hawking','Bantam',(SELECT category_id FROM categories WHERE category_name='Science'),2,2,'SC-01'),
('9780140449136','The Histories','Herodotus','Penguin Classics',(SELECT category_id FROM categories WHERE category_name='History'),1,1,'HI-01'),
('9780061120084','To Kill a Mockingbird','Harper Lee','Harper',(SELECT category_id FROM categories WHERE category_name='Fiction'),4,4,'FI-01'),
('9780743273565','The Great Gatsby','F. Scott Fitzgerald','Scribner',(SELECT category_id FROM categories WHERE category_name='Fiction'),2,2,'FI-02');
