<?php
// my_books.php - member: issued books, history and fines
require 'db.php';
require_once 'includes/functions.php';
require_member();
$id = (int)$_SESSION['member_id'];
$stmt = $conn->prepare(
    "SELECT b.title, b.author, i.issue_date, i.due_date, i.return_date, i.status,
            DATEDIFF(CURDATE(), i.due_date) AS days_over, f.amount, f.paid
     FROM issues i JOIN books b ON b.book_id = i.book_id
     LEFT JOIN fines f ON f.issue_id = i.issue_id
     WHERE i.member_id = ? ORDER BY i.issue_id DESC");
$stmt->bind_param("i", $id);
$stmt->execute();
$all = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$current = array_filter($all, fn($r) => $r['status'] === 'Issued');
$history = array_filter($all, fn($r) => $r['status'] === 'Returned');
$pending = 0;
foreach ($all as $r) if ($r['amount'] !== null && !$r['paid']) $pending += (float)$r['amount'];
foreach ($current as $r) if ($r['days_over'] > 0) $pending += $r['days_over'] * FINE_PER_DAY; // accruing
$page_title = 'My Books';
include 'includes/header.php';
?>
<h2>Welcome, <?= h($_SESSION['member_name']) ?></h2>
<div class="grid">
<div class="stat">Currently Issued<strong><?= count($current) ?> / <?= MAX_BOOKS ?></strong></div>
<div class="stat">Fines Due<strong>Rs. <?= number_format($pending, 2) ?></strong></div>
</div>
<div class="card"><h3>Currently Issued</h3><div class="table-wrap"><table>
<tr><th>Book</th><th>Issued</th><th>Due</th><th>Status</th></tr>
<?php if ($current): foreach ($current as $r): ?>
<tr><td><?= h($r['title']) ?> <span class="muted">by <?= h($r['author']) ?></span></td>
<td><?= h($r['issue_date']) ?></td><td><?= h($r['due_date']) ?></td>
<td><?= $r['days_over'] > 0
    ? '<span class="pill no">Overdue ' . (int)$r['days_over'] . ' day(s) &ndash; Rs. ' . $r['days_over'] * FINE_PER_DAY . '</span>'
    : '<span class="pill ok">On time</span>' ?></td></tr>
<?php endforeach; else: ?><tr><td colspan="4">No books currently issued.</td></tr><?php endif; ?>
</table></div></div>
<div class="card"><h3>Return History</h3><div class="table-wrap"><table>
<tr><th>Book</th><th>Issued</th><th>Returned</th><th>Fine</th></tr>
<?php if ($history): foreach ($history as $r): ?>
<tr><td><?= h($r['title']) ?></td><td><?= h($r['issue_date']) ?></td><td><?= h($r['return_date']) ?></td>
<td><?= $r['amount'] !== null ? 'Rs. ' . number_format((float)$r['amount'], 2) . ' (' . ($r['paid'] ? 'Paid' : 'Unpaid') . ')' : '&mdash;' ?></td></tr>
<?php endforeach; else: ?><tr><td colspan="4">No returned books yet.</td></tr><?php endif; ?>
</table></div></div>
<?php include 'includes/footer.php'; ?>
