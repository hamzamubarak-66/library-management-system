<?php
// db.php - database connection (credentials come from config.php)
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$cfgFile = __DIR__ . '/config.php';
if (!is_file($cfgFile)) {
    http_response_code(500);
    exit('config.php is missing. Copy config.sample.php to config.php, or run install_ubuntu.sh.');
}
$cfg = require $cfgFile;
try {
    $conn = new mysqli($cfg['db_host'], $cfg['db_user'], $cfg['db_pass'], $cfg['db_name']);
    $conn->set_charset('utf8mb4');
} catch (mysqli_sql_exception $e) {
    http_response_code(500);
    exit('Database connection failed. Check config.php and that MariaDB/MySQL is running.');
}
