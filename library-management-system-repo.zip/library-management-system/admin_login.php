<?php
// admin_login.php
require 'db.php';
require_once 'includes/functions.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $u = trim($_POST['username'] ?? '');
    $stmt = $conn->prepare("SELECT admin_id, full_name, password FROM admins WHERE username = ?");
    $stmt->bind_param("s", $u);
    $stmt->execute();
    $admin = $stmt->get_result()->fetch_assoc();
    if ($admin && password_verify($_POST['password'] ?? '', $admin['password'])) {
        session_regenerate_id(true);
        unset($_SESSION['member_id'], $_SESSION['member_name']);
        $_SESSION['admin_id'] = $admin['admin_id'];
        $_SESSION['admin_name'] = $admin['full_name'];
        redirect('admin/dashboard.php');
    }
    $error = 'Invalid username or password.';
}
$page_title = 'Admin Login';
include 'includes/header.php';
?>
<div class="card narrow"><h2>Administrator Login</h2>
<?php if ($error): ?><div class="error"><?= h($error) ?></div><?php endif; ?>
<form method="post"><?= csrf_field() ?>
<label>Username</label><input name="username" required autofocus>
<label>Password</label><input type="password" name="password" required>
<button>Login</button></form></div>
<?php include 'includes/footer.php'; ?>
