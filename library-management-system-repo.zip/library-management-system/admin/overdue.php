<?php
// admin/overdue.php - list all overdue books
require 'auth.php';
require '../db.php';
$result = $conn->query("SELECT i.issue_id, m.name, m.email, b.title, i.due_date, DATEDIFF(CURDATE(), i.due_date) AS days_late
  FROM issues i JOIN members m ON m.member_id=i.member_id JOIN books b ON b.book_id=i.book_id
  WHERE i.status='Issued' AND i.due_date < CURDATE() ORDER BY days_late DESC");
$page_title = 'Overdue Books';
include '../includes/header.php';
?>
<h2>Overdue Books</h2>
<div class="card"><div class="table-wrap"><table>
<tr><th>Member</th><th>Book</th><th>Due</th><th>Days late</th><th>Fine so far</th><th></th></tr>
<?php if ($result->num_rows): while ($r = $result->fetch_assoc()): ?>
<tr><td><?= h($r['name']) ?><br><span class="muted"><?= h($r['email']) ?></span></td><td><?= h($r['title']) ?></td><td><?= h($r['due_date']) ?></td>
<td><?= (int)$r['days_late'] ?></td><td>Rs. <?= (int)$r['days_late'] * FINE_PER_DAY ?></td>
<td><form method="post" action="return_book.php"><?= csrf_field() ?><input type="hidden" name="issue_id" value="<?= (int)$r['issue_id'] ?>"><input type="hidden" name="back" value="overdue">
<button class="small">Return</button></form></td></tr>
<?php endwhile; else: ?><tr><td colspan="6">No overdue books. 🎉</td></tr><?php endif; ?>
</table></div></div>
<?php include '../includes/footer.php'; ?>
