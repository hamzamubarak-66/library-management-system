<?php
// admin/delete_book.php (POST only)
require 'auth.php';
require '../db.php';
require_post();
$id = (int)($_POST['book_id'] ?? 0);
try {
    $stmt = $conn->prepare("DELETE FROM books WHERE book_id=?");
    $stmt->bind_param("i", $id); $stmt->execute();
    flash($stmt->affected_rows ? 'Book deleted.' : 'Book not found.', $stmt->affected_rows ? 'ok' : 'err');
} catch (mysqli_sql_exception $e) {
    flash('This book has issue records and cannot be deleted.', 'err');
}
redirect('books.php');
