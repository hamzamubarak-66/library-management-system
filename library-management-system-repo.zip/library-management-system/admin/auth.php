<?php
// admin/auth.php - include at the top of every admin page
require_once __DIR__ . '/../includes/functions.php';
if (empty($_SESSION['admin_id'])) redirect('../admin_login.php');
$base = '../';
$is_admin_page = true;
