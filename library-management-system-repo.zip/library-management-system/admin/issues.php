<?php
// admin/issues.php - all issue records
require 'auth.php';
require '../db.php';
$filter = $_GET['status'] ?? '';
$where = in_array($filter, ['Issued','Returned'], true) ? "WHERE i.status='$filter'" : '';
$rows = $conn->query("SELECT i.issue_id, m.name, b.title, i.issue_date, i.due_date, i.return_date, i.status, f.amount
  FROM issues i JOIN members m ON m.member_id=i.member_id JOIN books b ON b.book_id=i.book_id
  LEFT JOIN fines f ON f.issue_id=i.issue_id $where ORDER BY i.issue_id DESC");
$page_title = 'Issues and Returns';
include '../includes/header.php';
?>
<h2>Issues and Returns</h2>
<div class="card">
<div class="actions"><a class="btn small" href="issue_book.php">+ Issue Book</a>
<a class="btn small secondary" href="issues.php">All</a><a class="btn small secondary" href="?status=Issued">Issued</a><a class="btn small secondary" href="?status=Returned">Returned</a></div>
<div class="table-wrap"><table>
<tr><th>Member</th><th>Book</th><th>Issued</th><th>Due</th><th>Returned</th><th>Status</th><th>Fine</th><th></th></tr>
<?php if ($rows->num_rows): while ($r = $rows->fetch_assoc()): ?>
<tr><td><?= h($r['name']) ?></td><td><?= h($r['title']) ?></td><td><?= h($r['issue_date']) ?></td><td><?= h($r['due_date']) ?></td>
<td><?= h($r['return_date'] ?? '—') ?></td><td><?= h($r['status']) ?></td>
<td><?= $r['amount'] !== null ? 'Rs. ' . number_format((float)$r['amount'], 2) : '—' ?></td>
<td><?php if ($r['status'] === 'Issued'): ?>
<form method="post" action="return_book.php"><?= csrf_field() ?><input type="hidden" name="issue_id" value="<?= (int)$r['issue_id'] ?>"><button class="small">Return</button></form>
<?php endif; ?></td></tr>
<?php endwhile; else: ?><tr><td colspan="8">No records.</td></tr><?php endif; ?>
</table></div>
<p class="muted">Fine policy: Rs. <?= FINE_PER_DAY ?> for each day after the due date.</p></div>
<?php include '../includes/footer.php'; ?>
