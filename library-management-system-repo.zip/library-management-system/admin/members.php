<?php
// admin/members.php - add / block / delete members
require 'auth.php';
require '../db.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    $id = (int)($_POST['member_id'] ?? 0);
    try {
        if ($action === 'add') {
            $name = trim($_POST['name'] ?? ''); $email = trim($_POST['email'] ?? ''); $pw = $_POST['password'] ?? '';
            $phone = trim($_POST['phone'] ?? ''); $addr = trim($_POST['address'] ?? '');
            if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($pw) < 6) {
                flash('Name, a valid email and a password (6+ characters) are required.', 'err');
            } else {
                $hash = password_hash($pw, PASSWORD_DEFAULT);
                $st = $conn->prepare("INSERT INTO members (name,email,phone,address,password) VALUES (?,?,?,?,?)");
                $st->bind_param("sssss", $name, $email, $phone, $addr, $hash); $st->execute();
                flash('Member registered.');
            }
        } elseif ($action === 'toggle') {
            $st = $conn->prepare("UPDATE members SET status = IF(status='Active','Blocked','Active') WHERE member_id=?");
            $st->bind_param("i", $id); $st->execute(); flash('Member status updated.');
        } elseif ($action === 'delete') {
            $st = $conn->prepare("DELETE FROM members WHERE member_id=?");
            $st->bind_param("i", $id); $st->execute(); flash('Member deleted.');
        }
    } catch (mysqli_sql_exception $e) {
        flash($action === 'delete' ? 'This member has borrowing records and cannot be deleted. Block the account instead.'
                                   : 'That email is already registered.', 'err');
    }
    redirect('members.php');
}
$rows = $conn->query("SELECT m.*, (SELECT COUNT(*) FROM issues i WHERE i.member_id=m.member_id AND i.status='Issued') AS active
                      FROM members m ORDER BY member_id DESC");
$page_title = 'Members';
include '../includes/header.php';
?>
<h2>Library Members</h2>
<div class="card"><h3>Register a Member</h3>
<form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="add">
<label>Full name</label><input name="name" required maxlength="100">
<label>Email</label><input type="email" name="email" required maxlength="120">
<label>Phone</label><input name="phone" maxlength="20">
<label>Address</label><textarea name="address" rows="2"></textarea>
<label>Temporary password</label><input type="password" name="password" required minlength="6">
<button>Register Member</button></form></div>
<div class="card"><div class="table-wrap"><table>
<tr><th>Name</th><th>Email</th><th>Phone</th><th>Joined</th><th>Issued</th><th>Status</th><th>Actions</th></tr>
<?php while ($m = $rows->fetch_assoc()): ?>
<tr><td><?= h($m['name']) ?></td><td><?= h($m['email']) ?></td><td><?= h($m['phone']) ?></td><td><?= h($m['join_date']) ?></td>
<td><?= (int)$m['active'] ?></td>
<td><span class="pill <?= $m['status'] === 'Active' ? 'ok' : 'no' ?>"><?= h($m['status']) ?></span></td>
<td class="actions">
<form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="member_id" value="<?= (int)$m['member_id'] ?>">
<button class="small"><?= $m['status'] === 'Active' ? 'Block' : 'Unblock' ?></button></form>
<form method="post" onsubmit="return confirm('Delete this member?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="member_id" value="<?= (int)$m['member_id'] ?>">
<button class="small danger">Delete</button></form></td></tr>
<?php endwhile; ?></table></div></div>
<?php include '../includes/footer.php'; ?>
