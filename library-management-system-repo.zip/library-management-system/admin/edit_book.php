<?php
// admin/edit_book.php
require 'auth.php';
require '../db.php';
$id = (int)($_GET['id'] ?? $_POST['book_id'] ?? 0);
$stmt = $conn->prepare("SELECT * FROM books WHERE book_id=?");
$stmt->bind_param("i", $id); $stmt->execute();
$book = $stmt->get_result()->fetch_assoc();
if (!$book) { flash('Book not found.', 'err'); redirect('books.php'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $copies = max(1, (int)($_POST['copies'] ?? 1));
    $isbn = trim($_POST['isbn'] ?? ''); $title = trim($_POST['title'] ?? ''); $author = trim($_POST['author'] ?? '');
    $pub = trim($_POST['publisher'] ?? ''); $cat = (int)($_POST['category_id'] ?? 0); $shelf = trim($_POST['shelf'] ?? '');
    // available copies move by the same amount as total copies, never below zero
    $out = (int)$book['total_copies'] - (int)$book['available_copies']; // copies currently on loan
    if ($copies < $out) {
        flash("Total copies cannot be less than the $out copy/copies currently issued.", 'err');
    } elseif ($isbn === '' || $title === '' || $author === '') {
        flash('ISBN, title and author are required.', 'err');
    } else {
        try {
            $avail = $copies - $out;
            $stmt = $conn->prepare("UPDATE books SET isbn=?, title=?, author=?, publisher=?, category_id=?,
                                    total_copies=?, available_copies=?, shelf_location=? WHERE book_id=?");
            $stmt->bind_param("ssssiiisi", $isbn, $title, $author, $pub, $cat, $copies, $avail, $shelf, $id);
            $stmt->execute();
            flash('Book updated.');
            redirect('books.php');
        } catch (mysqli_sql_exception $e) {
            flash('Could not update. The ISBN may already exist.', 'err');
        }
    }
    $book = array_merge($book, ['isbn'=>$isbn,'title'=>$title,'author'=>$author,'publisher'=>$pub,
                                'category_id'=>$cat,'total_copies'=>$copies,'shelf_location'=>$shelf]);
}
$cats = $conn->query("SELECT * FROM categories ORDER BY category_name");
$submit_label = 'Save Changes';
$page_title = 'Edit Book';
include '../includes/header.php';
?>
<div class="card narrow"><h2>Edit Book</h2>
<?php include '../includes/book_form.php'; ?></div>
<?php include '../includes/footer.php'; ?>
