<?php
// admin/categories.php - add, edit and delete categories
require 'auth.php';
require '../db.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    $name = trim($_POST['category_name'] ?? '');
    $id = (int)($_POST['category_id'] ?? 0);
    try {
        if ($action === 'add' && $name !== '') {
            $st = $conn->prepare("INSERT INTO categories (category_name) VALUES (?)");
            $st->bind_param("s", $name); $st->execute(); flash('Category added.');
        } elseif ($action === 'edit' && $name !== '') {
            $st = $conn->prepare("UPDATE categories SET category_name=? WHERE category_id=?");
            $st->bind_param("si", $name, $id); $st->execute(); flash('Category renamed.');
        } elseif ($action === 'delete') {
            $st = $conn->prepare("DELETE FROM categories WHERE category_id=?");
            $st->bind_param("i", $id); $st->execute(); flash('Category deleted.');
        }
    } catch (mysqli_sql_exception $e) {
        flash($action === 'delete' ? 'Category still has books and cannot be deleted.' : 'That category name already exists.', 'err');
    }
    redirect('categories.php');
}
$cats = $conn->query("SELECT c.*, (SELECT COUNT(*) FROM books b WHERE b.category_id=c.category_id) AS n
                      FROM categories c ORDER BY category_name");
$page_title = 'Categories';
include '../includes/header.php';
?>
<h2>Book Categories</h2>
<div class="card"><h3>Add Category</h3>
<form method="post" class="search"><?= csrf_field() ?><input type="hidden" name="action" value="add">
<input name="category_name" placeholder="New category name" required maxlength="80"><button>Add</button></form></div>
<div class="card"><div class="table-wrap"><table><tr><th>Category</th><th>Books</th><th>Actions</th></tr>
<?php while ($c = $cats->fetch_assoc()): ?>
<tr><td colspan="1">
<form method="post" class="search"><?= csrf_field() ?><input type="hidden" name="action" value="edit">
<input type="hidden" name="category_id" value="<?= (int)$c['category_id'] ?>">
<input name="category_name" value="<?= h($c['category_name']) ?>" required maxlength="80"><button class="small">Rename</button></form></td>
<td><?= (int)$c['n'] ?></td>
<td><form method="post" onsubmit="return confirm('Delete this category?')"><?= csrf_field() ?>
<input type="hidden" name="action" value="delete"><input type="hidden" name="category_id" value="<?= (int)$c['category_id'] ?>">
<button class="small danger">Delete</button></form></td></tr>
<?php endwhile; ?></table></div></div>
<?php include '../includes/footer.php'; ?>
