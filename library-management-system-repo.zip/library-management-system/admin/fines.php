<?php
// admin/fines.php - view and collect fines
require 'auth.php';
require '../db.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $fid = (int)($_POST['fine_id'] ?? 0);
    $st = $conn->prepare("UPDATE fines SET paid=1, paid_date=CURDATE() WHERE fine_id=? AND paid=0");
    $st->bind_param("i", $fid); $st->execute();
    flash($st->affected_rows ? 'Fine marked as paid.' : 'Fine not found or already paid.', $st->affected_rows ? 'ok' : 'err');
    redirect('fines.php');
}
$rows = $conn->query("SELECT f.*, m.name, b.title, i.return_date FROM fines f
  JOIN issues i ON i.issue_id=f.issue_id JOIN members m ON m.member_id=i.member_id JOIN books b ON b.book_id=i.book_id
  ORDER BY f.paid ASC, f.fine_id DESC");
$tot = $conn->query("SELECT COALESCE(SUM(CASE WHEN paid=0 THEN amount END),0) u, COALESCE(SUM(CASE WHEN paid=1 THEN amount END),0) p FROM fines")->fetch_assoc();
$page_title = 'Fines';
include '../includes/header.php';
?>
<h2>Fines</h2>
<div class="grid"><div class="stat">Unpaid<strong>Rs. <?= number_format((float)$tot['u'], 2) ?></strong></div>
<div class="stat">Collected<strong>Rs. <?= number_format((float)$tot['p'], 2) ?></strong></div></div>
<div class="card"><div class="table-wrap"><table>
<tr><th>Member</th><th>Book</th><th>Returned</th><th>Amount</th><th>Status</th><th></th></tr>
<?php if ($rows->num_rows): while ($f = $rows->fetch_assoc()): ?>
<tr><td><?= h($f['name']) ?></td><td><?= h($f['title']) ?></td><td><?= h($f['return_date']) ?></td>
<td>Rs. <?= number_format((float)$f['amount'], 2) ?></td>
<td><?= $f['paid'] ? '<span class="pill ok">Paid ' . h($f['paid_date']) . '</span>' : '<span class="pill no">Unpaid</span>' ?></td>
<td><?php if (!$f['paid']): ?><form method="post"><?= csrf_field() ?><input type="hidden" name="fine_id" value="<?= (int)$f['fine_id'] ?>"><button class="small">Mark Paid</button></form><?php endif; ?></td></tr>
<?php endwhile; else: ?><tr><td colspan="6">No fines recorded.</td></tr><?php endif; ?>
</table></div></div>
<?php include '../includes/footer.php'; ?>
