<?php
// admin/return_book.php - return a book and calculate the fine (POST only)
require 'auth.php';
require '../db.php';
require_post();
$issue_id = (int)($_POST['issue_id'] ?? 0);
$conn->begin_transaction();
try {
    $st = $conn->prepare("SELECT book_id, GREATEST(0, DATEDIFF(CURDATE(), due_date)) AS late
                          FROM issues WHERE issue_id=? AND status='Issued' FOR UPDATE");
    $st->bind_param("i", $issue_id); $st->execute();
    $row = $st->get_result()->fetch_assoc();
    if (!$row) throw new Exception('Invalid or already returned.');
    $fine = (int)$row['late'] * FINE_PER_DAY;

    $st = $conn->prepare("UPDATE issues SET return_date=CURDATE(), status='Returned' WHERE issue_id=?");
    $st->bind_param("i", $issue_id); $st->execute();

    $st = $conn->prepare("UPDATE books SET available_copies = available_copies + 1 WHERE book_id=?");
    $st->bind_param("i", $row['book_id']); $st->execute();

    if ($fine > 0) {
        $st = $conn->prepare("INSERT INTO fines (issue_id, amount) VALUES (?, ?)");
        $st->bind_param("id", $issue_id, $fine); $st->execute();
    }
    $conn->commit();
    flash($fine > 0 ? "Book returned {$row['late']} day(s) late. Fine: Rs. $fine." : 'Book returned on time. No fine.');
} catch (Exception $e) {
    $conn->rollback();
    flash($e->getMessage(), 'err');
}
redirect(($_POST['back'] ?? '') === 'overdue' ? 'overdue.php' : 'issues.php');
