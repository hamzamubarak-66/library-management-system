<?php
// admin/issue_book.php - issue a book to a member (transaction)
require 'auth.php';
require '../db.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $member_id = (int)($_POST['member_id'] ?? 0);
    $book_id   = (int)($_POST['book_id'] ?? 0);
    $admin_id  = (int)$_SESSION['admin_id'];
    $conn->begin_transaction();
    try {
        // Lock the member row so two simultaneous issues cannot exceed the limit
        $st = $conn->prepare("SELECT status FROM members WHERE member_id=? FOR UPDATE");
        $st->bind_param("i", $member_id); $st->execute();
        $m = $st->get_result()->fetch_assoc();
        if (!$m || $m['status'] !== 'Active') throw new Exception('Member not found or account is blocked.');

        // Rule 1: at most MAX_BOOKS active loans
        $st = $conn->prepare("SELECT COUNT(*) c FROM issues WHERE member_id=? AND status='Issued'");
        $st->bind_param("i", $member_id); $st->execute();
        if ((int)$st->get_result()->fetch_assoc()['c'] >= MAX_BOOKS)
            throw new Exception('Member already has ' . MAX_BOOKS . ' books issued.');

        // Rule 2: same title cannot be borrowed twice at once
        $st = $conn->prepare("SELECT 1 FROM issues WHERE member_id=? AND book_id=? AND status='Issued'");
        $st->bind_param("ii", $member_id, $book_id); $st->execute();
        if ($st->get_result()->num_rows) throw new Exception('Member already has this book.');

        // Rule 3: a copy must be available (row locked while checking)
        $st = $conn->prepare("SELECT available_copies FROM books WHERE book_id=? FOR UPDATE");
        $st->bind_param("i", $book_id); $st->execute();
        $b = $st->get_result()->fetch_assoc();
        if (!$b || $b['available_copies'] < 1) throw new Exception('No copy of this book is available.');

        $days = LOAN_DAYS;
        $st = $conn->prepare("INSERT INTO issues (book_id,member_id,issued_by,issue_date,due_date)
                              VALUES (?,?,?,CURDATE(),DATE_ADD(CURDATE(), INTERVAL ? DAY))");
        $st->bind_param("iiii", $book_id, $member_id, $admin_id, $days); $st->execute();

        $st = $conn->prepare("UPDATE books SET available_copies = available_copies - 1 WHERE book_id=?");
        $st->bind_param("i", $book_id); $st->execute();

        $conn->commit();
        flash('Book issued. Due date is ' . LOAN_DAYS . ' days from today.');
        redirect('issues.php');
    } catch (Exception $e) {
        $conn->rollback();
        $error = $e->getMessage();
    }
}
$members = $conn->query("SELECT member_id,name,email FROM members WHERE status='Active' ORDER BY name");
$books = $conn->query("SELECT book_id,title,author,available_copies FROM books WHERE available_copies>0 ORDER BY title");
$page_title = 'Issue Book';
include '../includes/header.php';
?>
<div class="card narrow"><h2>Issue a Book</h2>
<?php if ($error): ?><div class="error"><?= h($error) ?></div><?php endif; ?>
<form method="post"><?= csrf_field() ?>
<label>Member</label><select name="member_id" required>
<?php while ($m = $members->fetch_assoc()): ?><option value="<?= (int)$m['member_id'] ?>"><?= h($m['name']) ?> &mdash; <?= h($m['email']) ?></option><?php endwhile; ?></select>
<label>Book</label><select name="book_id" required>
<?php while ($b = $books->fetch_assoc()): ?><option value="<?= (int)$b['book_id'] ?>"><?= h($b['title']) ?> (<?= h($b['author']) ?>) &ndash; <?= (int)$b['available_copies'] ?> available</option><?php endwhile; ?></select>
<p class="muted">Loan period <?= LOAN_DAYS ?> days &middot; limit <?= MAX_BOOKS ?> books per member.</p>
<button>Issue Book</button></form></div>
<?php include '../includes/footer.php'; ?>
