<?php
// admin/dashboard.php
require 'auth.php';
require '../db.php';
$s = $conn->query("SELECT
  (SELECT COUNT(*) FROM books) AS books,
  (SELECT COUNT(*) FROM members) AS members,
  (SELECT COUNT(*) FROM issues WHERE status='Issued') AS issued,
  (SELECT COUNT(*) FROM issues WHERE status='Issued' AND due_date < CURDATE()) AS overdue,
  (SELECT COALESCE(SUM(amount),0) FROM fines WHERE paid=0) AS unpaid")->fetch_assoc();
$recent = $conn->query("SELECT m.name, b.title, i.issue_date, i.due_date, i.status
  FROM issues i JOIN members m ON m.member_id=i.member_id JOIN books b ON b.book_id=i.book_id
  ORDER BY i.issue_id DESC LIMIT 8");
$page_title = 'Dashboard';
include '../includes/header.php';
?>
<h2>Administrator Dashboard</h2>
<p class="muted">Welcome, <?= h($_SESSION['admin_name']) ?></p>
<div class="grid">
<div class="stat">Total Books<strong><?= (int)$s['books'] ?></strong></div>
<div class="stat">Members<strong><?= (int)$s['members'] ?></strong></div>
<div class="stat">Books Issued<strong><?= (int)$s['issued'] ?></strong></div>
<div class="stat">Overdue<strong><?= (int)$s['overdue'] ?></strong></div>
<div class="stat">Unpaid Fines<strong>Rs. <?= number_format((float)$s['unpaid'], 2) ?></strong></div>
</div>
<div class="card"><h3>Recent Activity</h3><div class="table-wrap"><table>
<tr><th>Member</th><th>Book</th><th>Issued</th><th>Due</th><th>Status</th></tr>
<?php if ($recent->num_rows): while ($r = $recent->fetch_assoc()): ?>
<tr><td><?= h($r['name']) ?></td><td><?= h($r['title']) ?></td><td><?= h($r['issue_date']) ?></td><td><?= h($r['due_date']) ?></td><td><?= h($r['status']) ?></td></tr>
<?php endwhile; else: ?><tr><td colspan="5">No activity yet.</td></tr><?php endif; ?>
</table></div></div>
<?php include '../includes/footer.php'; ?>
