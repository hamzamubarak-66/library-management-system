<?php
// admin/books.php - list / search books
require 'auth.php';
require '../db.php';
$raw = trim($_GET['q'] ?? '');
$q = '%' . $raw . '%';
$stmt = $conn->prepare("SELECT b.*, c.category_name FROM books b JOIN categories c ON c.category_id=b.category_id
  WHERE b.title LIKE ? OR b.author LIKE ? OR b.isbn LIKE ? ORDER BY b.book_id DESC");
$stmt->bind_param("sss", $q, $q, $q);
$stmt->execute();
$books = $stmt->get_result();
$page_title = 'Manage Books';
include '../includes/header.php';
?>
<h2>Manage Books</h2>
<div class="card">
<div class="actions"><a class="btn" href="add_book.php">+ Add Book</a></div>
<form class="search" method="get" style="margin-top:12px"><input name="q" value="<?= h($raw) ?>" placeholder="Search title, author or ISBN..."><button>Search</button></form>
<div class="table-wrap"><table>
<tr><th>Title</th><th>Author</th><th>ISBN</th><th>Category</th><th>Avail / Total</th><th>Shelf</th><th>Actions</th></tr>
<?php if ($books->num_rows): while ($b = $books->fetch_assoc()): ?>
<tr><td><?= h($b['title']) ?></td><td><?= h($b['author']) ?></td><td><?= h($b['isbn']) ?></td><td><?= h($b['category_name']) ?></td>
<td><?= (int)$b['available_copies'] ?> / <?= (int)$b['total_copies'] ?></td><td><?= h($b['shelf_location']) ?></td>
<td class="actions"><a class="btn small" href="edit_book.php?id=<?= (int)$b['book_id'] ?>">Edit</a>
<form method="post" action="delete_book.php" onsubmit="return confirm('Delete this book?')"><?= csrf_field() ?>
<input type="hidden" name="book_id" value="<?= (int)$b['book_id'] ?>"><button class="small danger">Delete</button></form></td></tr>
<?php endwhile; else: ?><tr><td colspan="7">No books found.</td></tr><?php endif; ?>
</table></div></div>
<?php include '../includes/footer.php'; ?>
