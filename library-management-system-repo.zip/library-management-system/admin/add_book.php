<?php
// admin/add_book.php
require 'auth.php';
require '../db.php';
$book = ['isbn'=>'','title'=>'','author'=>'','publisher'=>'','category_id'=>0,'total_copies'=>1,'shelf_location'=>''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $copies = max(1, (int)($_POST['copies'] ?? 1));
    $isbn = trim($_POST['isbn'] ?? ''); $title = trim($_POST['title'] ?? ''); $author = trim($_POST['author'] ?? '');
    $pub = trim($_POST['publisher'] ?? ''); $cat = (int)($_POST['category_id'] ?? 0); $shelf = trim($_POST['shelf'] ?? '');
    $book = ['isbn'=>$isbn,'title'=>$title,'author'=>$author,'publisher'=>$pub,'category_id'=>$cat,'total_copies'=>$copies,'shelf_location'=>$shelf];
    if ($isbn === '' || $title === '' || $author === '') {
        flash('ISBN, title and author are required.', 'err');
    } else {
        try {
            $stmt = $conn->prepare("INSERT INTO books (isbn,title,author,publisher,category_id,total_copies,available_copies,shelf_location)
                                    VALUES (?,?,?,?,?,?,?,?)");
            $stmt->bind_param("ssssiiis", $isbn, $title, $author, $pub, $cat, $copies, $copies, $shelf);
            $stmt->execute();
            flash('Book added successfully.');
            redirect('books.php');
        } catch (mysqli_sql_exception $e) {
            flash('Could not add book. The ISBN may already exist or the category is invalid.', 'err');
        }
    }
}
$cats = $conn->query("SELECT * FROM categories ORDER BY category_name");
$submit_label = 'Add Book';
$page_title = 'Add Book';
include '../includes/header.php';
?>
<div class="card narrow"><h2>Add Book</h2>
<?php include '../includes/book_form.php'; ?></div>
<?php include '../includes/footer.php'; ?>
