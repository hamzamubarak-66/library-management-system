<?php
// member_register.php
require 'db.php';
require_once 'includes/functions.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $name = trim($_POST['name'] ?? ''); $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? ''); $address = trim($_POST['address'] ?? '');
    $pw = $_POST['password'] ?? '';
    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($pw) < 6) {
        $error = 'Enter a name, a valid email and a password of at least 6 characters.';
    } else {
        try {
            $hash = password_hash($pw, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO members (name, email, phone, address, password) VALUES (?,?,?,?,?)");
            $stmt->bind_param("sssss", $name, $email, $phone, $address, $hash);
            $stmt->execute();
            flash('Registration successful. Please log in.');
            redirect('member_login.php');
        } catch (mysqli_sql_exception $e) {
            $error = 'This email is already registered.';
        }
    }
}
$page_title = 'Member Registration';
include 'includes/header.php';
?>
<div class="card narrow"><h2>Create Member Account</h2>
<?php if ($error): ?><div class="error"><?= h($error) ?></div><?php endif; ?>
<form method="post"><?= csrf_field() ?>
<label>Full name</label><input name="name" required value="<?= h($_POST['name'] ?? '') ?>">
<label>Email</label><input type="email" name="email" required value="<?= h($_POST['email'] ?? '') ?>">
<label>Phone (optional)</label><input name="phone" value="<?= h($_POST['phone'] ?? '') ?>">
<label>Address (optional)</label><textarea name="address" rows="2"><?= h($_POST['address'] ?? '') ?></textarea>
<label>Password (minimum 6 characters)</label><input type="password" name="password" required minlength="6">
<button>Register</button></form></div>
<?php include 'includes/footer.php'; ?>
